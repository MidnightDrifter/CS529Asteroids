README

No fancy features just yet--just the basics and minimum described in the handout, no special cases.
